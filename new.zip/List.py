fruits = ["banana","apple","orange"]
a =[1,2,3]
b = [4,5,6]
# fruits.append("Kola") add new data
# fruits.insert(2,"goaba") add indexing postion data
# fruits.remove("orange")
# fruits.pop(1)
# print(fruits.reverse())

print(fruits)